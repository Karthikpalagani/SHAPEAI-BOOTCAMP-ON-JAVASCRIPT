import React from "react";

function Info(){
  return(
    <div className="note">
      <h1>JAVASCRIPT AND REACT JS </h1>
      </div>
  );
}

export default Info;