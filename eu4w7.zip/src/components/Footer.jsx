import React from "react";

function Footer(){
  return(
    <p>copyright by Shapeai @{new Date().getFullYear()}
   </p> 
  );
}

export default Footer;