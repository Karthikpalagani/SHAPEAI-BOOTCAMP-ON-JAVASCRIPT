import React from "react";

function Header(){
  return(
    <Header>
      <h1>SHAPEAI BOOTCAMP </h1>
      </Header>
  );
}

export default Header;